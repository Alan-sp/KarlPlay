/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[57];
    char stringdata0[586];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 9), // "beginplay"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 9), // "file_null"
QT_MOC_LITERAL(4, 32, 10), // "is_sign_in"
QT_MOC_LITERAL(5, 43, 9), // "initMysql"
QT_MOC_LITERAL(6, 53, 10), // "initPlayer"
QT_MOC_LITERAL(7, 64, 7), // "initPro"
QT_MOC_LITERAL(8, 72, 13), // "showPlayMedia"
QT_MOC_LITERAL(9, 86, 9), // "readmysql"
QT_MOC_LITERAL(10, 96, 14), // "mytablewidget*"
QT_MOC_LITERAL(11, 111, 11), // "getfileName"
QT_MOC_LITERAL(12, 123, 4), // "file"
QT_MOC_LITERAL(13, 128, 6), // "reinit"
QT_MOC_LITERAL(14, 135, 7), // "boxitem"
QT_MOC_LITERAL(15, 143, 1), // "i"
QT_MOC_LITERAL(16, 145, 4), // "text"
QT_MOC_LITERAL(17, 150, 13), // "QTableWidget*"
QT_MOC_LITERAL(18, 164, 8), // "queuefun"
QT_MOC_LITERAL(19, 173, 8), // "getPName"
QT_MOC_LITERAL(20, 182, 8), // "filename"
QT_MOC_LITERAL(21, 191, 8), // "getMName"
QT_MOC_LITERAL(22, 200, 7), // "getname"
QT_MOC_LITERAL(23, 208, 9), // "showlocal"
QT_MOC_LITERAL(24, 218, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(25, 235, 9), // "localinit"
QT_MOC_LITERAL(26, 245, 14), // "insert_nowplay"
QT_MOC_LITERAL(27, 260, 9), // "innowplay"
QT_MOC_LITERAL(28, 270, 13), // "songqueue_fun"
QT_MOC_LITERAL(29, 284, 9), // "local_fun"
QT_MOC_LITERAL(30, 294, 5), // "reply"
QT_MOC_LITERAL(31, 300, 14), // "QNetworkReply*"
QT_MOC_LITERAL(32, 315, 6), // "search"
QT_MOC_LITERAL(33, 322, 9), // "parseJson"
QT_MOC_LITERAL(34, 332, 6), // "reply2"
QT_MOC_LITERAL(35, 339, 10), // "parseJson2"
QT_MOC_LITERAL(36, 350, 4), // "json"
QT_MOC_LITERAL(37, 355, 6), // "reply3"
QT_MOC_LITERAL(38, 362, 9), // "local_img"
QT_MOC_LITERAL(39, 372, 14), // "play_net_Music"
QT_MOC_LITERAL(40, 387, 12), // "is_net_music"
QT_MOC_LITERAL(41, 400, 11), // "initlrc_win"
QT_MOC_LITERAL(42, 412, 8), // "buildlrc"
QT_MOC_LITERAL(43, 421, 13), // "PixmapToRound"
QT_MOC_LITERAL(44, 435, 8), // "QPixmap&"
QT_MOC_LITERAL(45, 444, 7), // "is_like"
QT_MOC_LITERAL(46, 452, 8), // "fun_like"
QT_MOC_LITERAL(47, 461, 10), // "fun_like_w"
QT_MOC_LITERAL(48, 472, 10), // "init_local"
QT_MOC_LITERAL(49, 483, 9), // "init_like"
QT_MOC_LITERAL(50, 493, 12), // "songlist_add"
QT_MOC_LITERAL(51, 506, 12), // "initsonglist"
QT_MOC_LITERAL(52, 519, 15), // "show_List_music"
QT_MOC_LITERAL(53, 535, 13), // "this_songlist"
QT_MOC_LITERAL(54, 549, 15), // "show_list_music"
QT_MOC_LITERAL(55, 565, 10), // "fun_list_w"
QT_MOC_LITERAL(56, 576, 9) // "updatepos"

    },
    "MainWindow\0beginplay\0\0file_null\0"
    "is_sign_in\0initMysql\0initPlayer\0initPro\0"
    "showPlayMedia\0readmysql\0mytablewidget*\0"
    "getfileName\0file\0reinit\0boxitem\0i\0"
    "text\0QTableWidget*\0queuefun\0getPName\0"
    "filename\0getMName\0getname\0showlocal\0"
    "QListWidgetItem*\0localinit\0insert_nowplay\0"
    "innowplay\0songqueue_fun\0local_fun\0"
    "reply\0QNetworkReply*\0search\0parseJson\0"
    "reply2\0parseJson2\0json\0reply3\0local_img\0"
    "play_net_Music\0is_net_music\0initlrc_win\0"
    "buildlrc\0PixmapToRound\0QPixmap&\0is_like\0"
    "fun_like\0fun_like_w\0init_local\0init_like\0"
    "songlist_add\0initsonglist\0show_List_music\0"
    "this_songlist\0show_list_music\0fun_list_w\0"
    "updatepos"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      45,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  239,    2, 0x06 /* Public */,
       3,    0,  240,    2, 0x06 /* Public */,
       4,    0,  241,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  242,    2, 0x08 /* Private */,
       6,    0,  243,    2, 0x08 /* Private */,
       7,    0,  244,    2, 0x08 /* Private */,
       8,    0,  245,    2, 0x08 /* Private */,
       9,    3,  246,    2, 0x08 /* Private */,
      11,    1,  253,    2, 0x08 /* Private */,
      13,    1,  256,    2, 0x08 /* Private */,
      14,    3,  259,    2, 0x08 /* Private */,
      18,    3,  266,    2, 0x08 /* Private */,
      19,    1,  273,    2, 0x08 /* Private */,
      21,    1,  276,    2, 0x08 /* Private */,
      22,    1,  279,    2, 0x08 /* Private */,
      23,    1,  282,    2, 0x08 /* Private */,
      25,    1,  285,    2, 0x08 /* Private */,
      26,    4,  288,    2, 0x08 /* Private */,
      27,    0,  297,    2, 0x08 /* Private */,
      28,    2,  298,    2, 0x08 /* Private */,
      29,    2,  303,    2, 0x08 /* Private */,
      30,    1,  308,    2, 0x08 /* Private */,
      32,    2,  311,    2, 0x08 /* Private */,
      33,    2,  316,    2, 0x08 /* Private */,
      34,    1,  321,    2, 0x08 /* Private */,
      35,    1,  324,    2, 0x08 /* Private */,
      37,    1,  327,    2, 0x08 /* Private */,
      38,    1,  330,    2, 0x08 /* Private */,
      39,    2,  333,    2, 0x08 /* Private */,
      40,    1,  338,    2, 0x08 /* Private */,
      41,    0,  341,    2, 0x08 /* Private */,
      42,    1,  342,    2, 0x08 /* Private */,
      43,    2,  345,    2, 0x08 /* Private */,
      45,    1,  350,    2, 0x08 /* Private */,
      46,    2,  353,    2, 0x08 /* Private */,
      47,    2,  358,    2, 0x08 /* Private */,
      48,    0,  363,    2, 0x08 /* Private */,
      49,    0,  364,    2, 0x08 /* Private */,
      50,    1,  365,    2, 0x08 /* Private */,
      51,    0,  368,    2, 0x08 /* Private */,
      52,    1,  369,    2, 0x08 /* Private */,
      53,    1,  372,    2, 0x08 /* Private */,
      54,    1,  375,    2, 0x08 /* Private */,
      55,    2,  378,    2, 0x08 /* Private */,
      56,    0,  383,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 10, QMetaType::QString, QMetaType::QString,    2,    2,    2,
    QMetaType::QStringList, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, 0x80000000 | 17,   15,   16,    2,
    QMetaType::Void, 0x80000000 | 10, QMetaType::QString, QMetaType::QString,    2,    2,    2,
    QMetaType::QString, QMetaType::QString,   20,
    QMetaType::QString, QMetaType::QString,   20,
    QMetaType::QString, QMetaType::QString,    2,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void, 0x80000000 | 17,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 31,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, 0x80000000 | 31,   30,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void, 0x80000000 | 31,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Bool, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::QPixmap, 0x80000000 | 44, QMetaType::Int,    2,    2,
    QMetaType::QString, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->beginplay(); break;
        case 1: _t->file_null(); break;
        case 2: _t->is_sign_in(); break;
        case 3: _t->initMysql(); break;
        case 4: _t->initPlayer(); break;
        case 5: _t->initPro(); break;
        case 6: _t->showPlayMedia(); break;
        case 7: _t->readmysql((*reinterpret_cast< mytablewidget*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 8: { QStringList _r = _t->getfileName((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->reinit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->boxitem((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QTableWidget*(*)>(_a[3]))); break;
        case 11: _t->queuefun((*reinterpret_cast< mytablewidget*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 12: { QString _r = _t->getPName((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 13: { QString _r = _t->getMName((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 14: { QString _r = _t->getname((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 15: _t->showlocal((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 16: _t->localinit((*reinterpret_cast< QTableWidget*(*)>(_a[1]))); break;
        case 17: _t->insert_nowplay((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 18: _t->innowplay(); break;
        case 19: _t->songqueue_fun((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 20: _t->local_fun((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 21: _t->reply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 22: _t->search((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 23: _t->parseJson((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 24: _t->reply2((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 25: _t->parseJson2((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->reply3((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 27: _t->local_img((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 28: _t->play_net_Music((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 29: { bool _r = _t->is_net_music((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 30: _t->initlrc_win(); break;
        case 31: _t->buildlrc((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 32: { QPixmap _r = _t->PixmapToRound((*reinterpret_cast< QPixmap(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QPixmap*>(_a[0]) = std::move(_r); }  break;
        case 33: { QString _r = _t->is_like((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 34: _t->fun_like((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 35: _t->fun_like_w((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 36: _t->init_local(); break;
        case 37: _t->init_like(); break;
        case 38: _t->songlist_add((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 39: _t->initsonglist(); break;
        case 40: _t->show_List_music((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 41: _t->this_songlist((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 42: _t->show_list_music((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 43: _t->fun_list_w((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 44: _t->updatepos(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< mytablewidget* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 2:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTableWidget* >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< mytablewidget* >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTableWidget* >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 26:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::beginplay)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::file_null)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::is_sign_in)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 45)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 45;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 45)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 45;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::beginplay()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::file_null()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::is_sign_in()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
