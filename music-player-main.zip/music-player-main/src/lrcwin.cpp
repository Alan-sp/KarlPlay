#include "lrcwin.h"

lrcwin_::lrcwin_(QWidget *parent) : QWidget(parent)
{

}
