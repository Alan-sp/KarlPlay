#ifndef LRCWIN_H
#define LRCWIN_H

#include <QWidget>

class lrcwin : public QWidget
{
    Q_OBJECT
public:
    explicit lrcwin(QWidget *parent = nullptr);

signals:

};

#endif // LRCWIN_H
